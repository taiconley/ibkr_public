SELECT *
FROM public.predictions;