SELECT *
FROM public.tickdata_jul17;