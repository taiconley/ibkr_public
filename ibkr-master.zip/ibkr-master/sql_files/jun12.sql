SELECT *
FROM public.tickdata_jun12;